$(function(){
  $(window).mousemove(function(e){
    $('.contenedor-cubo.manual').css('transform', 'rotateX(' + - e.pageY + 'deg)' + 'rotateY(' + e.pageX + 'deg)');
  }); 
})

jQuery(document).ready(function( $ ) {
    
$( "#cambiar" ).click(function() {
    if($( ".contenedor-cubo" ).hasClass('auto')){
        $( ".contenedor-cubo" ).removeClass('auto');
        $( ".contenedor-cubo" ).addClass('manual');
        $( "#cambiar" ).html('Automatico');
    }else{
        $( ".contenedor-cubo" ).removeClass('manual');
        $( ".contenedor-cubo" ).addClass('auto');
        $( "#cambiar" ).html('Manual');
    }
        
});
    
});
